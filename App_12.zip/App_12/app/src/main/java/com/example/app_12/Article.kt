package com.example.app_12

import java.util.Date

class Article(
    val id: Int?,
    val name: String,
    val cost: Double?,
    val date: String?
)